<?php
  echo "<script>
          location.href = 'auth/login.php';
        </script>";
?>