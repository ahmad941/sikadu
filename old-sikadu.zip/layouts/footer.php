<!-- Footer -->
<footer class="footer">
	<div class="container-fluid">
		<nav class="pull-left">
			<ul class="nav">
				<li class="nav-item">
					<a class="nav-link" href="#">
						Bantuan
					</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#">
						Lisensi
					</a>
				</li>
			</ul>
		</nav>
		<div class="copyright ml-auto">
			2020, STMIK Kharisma</a>
		</div>				
	</div>
</footer>
<!-- End Footer -->